# 崩坏3扫码器 / bh3_login_simulation

免去每次登陆桌面服要打开臃肿的客户端的麻烦  

## 支持协议 / Supported protocol

Official  
Bilibili 
Xiaomi  
UC(豌豆荚/九游)  

华为因为开发者账号需要18岁暂不支持  


## B站演示视频 / Video

https://www.bilibili.com/video/BV1hA411e7s3/

package com.github.haocen2004.login_simulation.util;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import org.json.JSONException;
import org.json.JSONObject;

import static com.github.haocen2004.login_simulation.util.Tools.getOAServer;

public class RoleData {
    private String open_id;
    private String combo_id;
    private String combo_token;
    private String asterisk_name;
    private String channel_id;
    private JSONObject oaserver;
    private String account_type;
    private String oa_req_key;


    public RoleData(String open_id,String combo_id,String combo_token,String asterisk_name,String channel_id,String account_type,String oa_req_key){
        this.open_id = open_id;
        this.combo_id = combo_id;
        this.combo_token = combo_token;
        this.asterisk_name = asterisk_name;
        this.channel_id = channel_id;
        this.account_type = account_type;
        this.oa_req_key = oa_req_key;
        new Thread(getOA_runnable).start();
    }

    public String getOpen_id() {
        return open_id;
    }

    public String getAsterisk_name() {
        return asterisk_name;
    }

    public String getCombo_id() {
        return combo_id;
    }

    public String getCombo_token() {
        return combo_token;
    }

    public String getAccount_type() {
        return account_type;
    }

    public String getChannel_id() {
        return channel_id;
    }

    public JSONObject getOaserver() {
        if (oaserver == null){
            oaserver = getOAServer(this);
        }
        return oaserver;
    }

    public String getOa_req_key(){
        return oa_req_key;
    }


    @SuppressLint("HandlerLeak")
    Handler login_handler = new Handler(){

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            Bundle data = msg.getData();
            String feedback = data.getString("value");
            try {
                oaserver = new JSONObject(feedback);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };
    Runnable getOA_runnable = new Runnable() {
        @Override
        public void run() {

            Message msg = new Message();
            Bundle data = new Bundle();
            data.putString("value", getOAServer(RoleData.this).toString());
            msg.setData(data);
            login_handler.sendMessage(msg);
        }
    };
}


package com.github.haocen2004.login_simulation.login;

import com.github.haocen2004.login_simulation.util.RoleData;

public interface Login {
    void login();
    void logout();
    RoleData getRole();
//    String getCombo_token();
//    String getCombo_id();
//    String getUid(); //Unused
    boolean isLogin();
}
